//
//  HWInstallView.h
//  HWProgress
//
//  Created by sxmaps_w on 2017/3/3.
//  Copyright © 2017年 hero_wqb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HWInstallView : UIView

@property (nonatomic, assign) CGFloat progress;

@end
