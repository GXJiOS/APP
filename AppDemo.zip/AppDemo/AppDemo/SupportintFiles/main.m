//
//  main.m
//  AppDemo
//
//  Created by GXJ on 2017/9/25.
//  Copyright © 2017年 GXJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
