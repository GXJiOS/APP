//
//  ZMProgressViewController.m
//  AppFrame
//
//  Created by GXJ on 2017/5/11.
//  Copyright © 2017年 GXJ. All rights reserved.
//

#import "ZMProgressViewController.h"

@interface ZMProgressViewController ()

@end

@implementation ZMProgressViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"仿芝麻信用";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
